def calc_bmi(weight, height):
    return round(weight/(height*0.01)**2,1)