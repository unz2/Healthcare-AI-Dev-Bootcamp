def classify_bmi(bmi):
    if bmi < 18.5:
        bmi_result = '저체중'
    elif bmi <= 22.9:
        bmi_result = '정상'
    elif bmi <= 24.9:
        bmi_result = '과체중'
    else:
        bmi_result = '비만'
    return bmi_result