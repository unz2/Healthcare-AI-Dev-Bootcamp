from bmi_utils import calc_bmi, classify_bmi

print('====== bmi 계산기 ======')
weight = float(input('체중(kg)을 입력하세요 : '))
height = float(input('키(cm)를 입력하세요 : '))
bmi = calc_bmi(weight, height)
bmi_result = classify_bmi(bmi)

print('='*23)
print(f'당신의 체중: {weight}kg, 키: {height}cm')
print(f'당신의 bmi: {bmi}, {bmi_result}입니다.')